package societyapp.idealake.com

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
