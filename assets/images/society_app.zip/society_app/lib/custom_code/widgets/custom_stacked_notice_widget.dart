// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:swipe_deck/swipe_deck.dart';

// Set your widget name, define your parameter, and then add the
// boilerplate code using the button on the right!

class CustomStackedNoticeCards extends StatelessWidget {
  List noticeList = ['a', 'b', 'c', 'd', 'e'];

  @override
  Widget build(BuildContext context) {
    return SwipeDeck(
      startIndex: 2,
      aspectRatio: 0.7,
      emptyIndicator: Container(
        child: Center(
          child: Text("Nothing Here"),
        ),
      ),
      cardSpreadInDegrees: 60, // Change the Spread of Background Cards
      onSwipeLeft: () {},
      onSwipeRight: () {},
      onChange: (index) {},
      widgets: noticeList
          .asMap()
          .entries
          .map((e) => GestureDetector(
                onTap: () {
                  print(e);
                },
                child: ClipRRect(
                    borderRadius: e.key % 2 == 0
                        ? BorderRadius.only(topLeft: Radius.circular(40))
                        : BorderRadius.only(topRight: Radius.circular(40)),
                    child: Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(color: Colors.blue),
                          child: Column(
                            children: [
                              Text('Upcoming recycling drive!'),
                              Text('D wing  |  20th Feb'),
                            ],
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(color: Colors.blue),
                          child: Column(
                            children: [
                              Text(
                                  'Jun. NO Objection Certificates (NOCs) are required by members of Society for various purposes. NOCs may be required as and when a member is leasing the property or in case he/she is selling his/her property or at...'),
                            ],
                          ),
                        )
                      ],
                    )),
              ))
          .toList(),
    );
  }
}
