// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Imports custom functions

class BottomSheetOne extends StatefulWidget {
  const BottomSheetOne({
    Key? key,
    this.width,
    this.height,
    required this.imagePath,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String imagePath;

  @override
  _BottomSheetOneState createState() => _BottomSheetOneState();
}

class _BottomSheetOneState extends State<BottomSheetOne> {
  @override
  Widget build(BuildContext context) {
    return SocietyBottomSheet(
      btmWidget: Container(
        padding: const EdgeInsets.all(20),
        width: MediaQuery.of(context).size.width,
        child: Column(
          children: [
            const SizedBox(height: 20),
            Image.asset(widget.imagePath, width: 140, height: 140),
            const Text(
              "All Done!",
              style: TextStyle(
                  color: Color(0xff1B1D21),
                  fontFamily: "Open Sans",
                  fontSize: 36.0,
                  fontWeight: FontWeight.w700,
                  wordSpacing: -0.5,
                  height: 1.5),
            ),
            const Text("You're all set to manage your society needs.",
                style: TextStyle(
                    color: Color.fromRGBO(0, 0, 0, 0.5),
                    fontFamily: "Open Sans",
                    fontSize: 14.0,
                    fontWeight: FontWeight.w600,
                    wordSpacing: -0.5,
                    height: 1.5)),
            const SizedBox(height: 32),
            SocietyButton(onPressed: () {}, label: 'Add Flat / Villa '),
            const SizedBox(height: 16),
            const SocietyOutlineButton(label: "Skip")
          ],
        ),
      ),
    );
  }
}

class SocietyBottomSheet extends StatelessWidget {
  final Widget btmWidget;

  const SocietyBottomSheet({Key? key, required this.btmWidget})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned(
          width: MediaQuery.of(context).size.width,
          top: -35,
          child: CircleAvatar(
            radius: 20,
            backgroundColor: Colors.white,
            child: IconButton(
              splashRadius: 25,
              color: const Color.fromRGBO(0, 0, 0, 0.5),
              onPressed: () {
                // Navigator.pop(context);
              },
              icon: const Icon(Icons.close),
              iconSize: 20,
            ),
          ),
        ),
        Container(
          color: Colors.transparent,
          child: CustomPaint(
            size: Size(MediaQuery.of(context).size.width, 460),
            painter: CustomBTShape(),
            child: btmWidget,
          ),
        ),
      ],
    );
  }
}

class CustomBTShape extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Path path = Path();
    path.moveTo(size.width * 0.1183511, 0);
    path.cubicTo(
        size.width * 0.05372207,
        0,
        size.width * 0.001329787,
        size.height * 0.04301201,
        size.width * 0.001329787,
        size.height * 0.09606987);
    path.lineTo(size.width * 0.001329787, size.height * 1.063319);
    path.lineTo(size.width * 0.9986702, size.height * 1.063319);
    path.lineTo(size.width * 0.9986702, size.height * 0.09606987);
    path.cubicTo(size.width * 0.9986702, size.height * 0.04301201,
        size.width * 0.9462793, 0, size.width * 0.8816489, 0);
    path.lineTo(size.width * 0.5850878, 0);
    path.cubicTo(
        size.width * 0.5775027,
        0,
        size.width * 0.5702899,
        size.height * 0.002714367,
        size.width * 0.5653404,
        size.height * 0.007434258);
    path.lineTo(size.width * 0.5576170, size.height * 0.01479635);
    path.cubicTo(
        size.width * 0.5239894,
        size.height * 0.04685699,
        size.width * 0.4623856,
        size.height * 0.04374498,
        size.width * 0.4337979,
        size.height * 0.008541616);
    path.cubicTo(size.width * 0.4294654, size.height * 0.003205284,
        size.width * 0.4221702, 0, size.width * 0.4143564, 0);
    path.lineTo(size.width * 0.1183511, 0);
    path.close();
    path.moveTo(size.width * 0.9908165, size.height * 1.279092);
    path.lineTo(size.width * 0.009182872, size.height * 1.279092);
    path.lineTo(size.width * 0.009182872, size.height * 1.890830);
    path.lineTo(size.width * 0.9908165, size.height * 1.890830);
    path.lineTo(size.width * 0.9908165, size.height * 1.279092);
    path.close();

    Paint colPaint = Paint()..style = PaintingStyle.fill;
    colPaint.color = Colors.white;
    canvas.drawPath(path, colPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class SocietyButton extends StatelessWidget {
  const SocietyButton({Key? key, required this.label, this.onPressed})
      : super(key: key);

  final String label;
  final void Function()? onPressed;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ButtonStyle(
        backgroundColor:
            MaterialStateProperty.all<Color>(const Color(0xff9383FA)),
        minimumSize:
            MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
        elevation: MaterialStateProperty.all<double>(0),
      ),
      onPressed: onPressed,
      child: Text(
        label,
        style: const TextStyle(
            color: Colors.white,
            fontFamily: "Open Sans",
            fontSize: 16.0,
            fontWeight: FontWeight.w600,
            wordSpacing: -0.5,
            height: 1.5),
      ),
    );
  }
}

class SocietyOutlineButton extends StatelessWidget {
  const SocietyOutlineButton({Key? key, required this.label, this.onPressed})
      : super(key: key);

  final String label;
  final void Function()? onPressed;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all<Color>(Colors.transparent),
        minimumSize:
            MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
        elevation: MaterialStateProperty.all<double>(0),
        shape: MaterialStateProperty.all<OutlinedBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
            side: const BorderSide(
              color: Color(0xffD9D9D9),
              width: 1.0,
            ),
          ),
        ),
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(label,
              style: const TextStyle(
                  color: Color.fromRGBO(0, 0, 0, 0.5),
                  fontFamily: "Open Sans",
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                  wordSpacing: -0.5,
                  height: 1.5)),
          const SizedBox(width: 10),
          const Icon(Icons.arrow_forward),
        ],
      ),
    );
  }
}
