import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widgets/mobile_validator_field/mobile_validator_field_widget.dart';
import '/widgets/text_field/text_field_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SignUpScreenModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // Model for textField component.
  late TextFieldModel textFieldModel1;
  // Model for textField component.
  late TextFieldModel textFieldModel2;
  // Model for mobileValidatorField component.
  late MobileValidatorFieldModel mobileValidatorFieldModel;
  // State field(s) for Checkbox widget.
  bool? checkboxValue;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    textFieldModel1 = createModel(context, () => TextFieldModel());
    textFieldModel2 = createModel(context, () => TextFieldModel());
    mobileValidatorFieldModel =
        createModel(context, () => MobileValidatorFieldModel());

    textFieldModel1.textControllerValidator = _formTextFieldValidator1;
    textFieldModel2.textControllerValidator = _formTextFieldValidator2;
    mobileValidatorFieldModel.textControllerValidator =
        _formTextFieldValidator3;
  }

  void dispose() {
    textFieldModel1.dispose();
    textFieldModel2.dispose();
    mobileValidatorFieldModel.dispose();
  }

  /// Additional helper methods are added here.

  String? _formTextFieldValidator1(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 5) {
      return 'Maximum 5 charaters allowed.';
    }
    if (val.length > 50) {
      return 'Maximum 50 charaters allowed.';
    }
    if (!RegExp(kTextValidatorUsernameRegex).hasMatch(val)) {
      return 'Must start with a letter and can only contain letters, digits and - or _.';
    }
    return null;
  }

  String? _formTextFieldValidator2(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 10) {
      return 'Requires at least 10 characters.';
    }
    if (val.length > 50) {
      return 'Maximum 50 charaters allowed.';
    }
    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return 'Has to be a valid email address.';
    }
    return null;
  }

  String? _formTextFieldValidator3(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 10) {
      return 'Requires at least 10 characters.';
    }
    if (val.length > 11) {
      return 'Maximum 10 Digits allowed.';
    }

    return null;
  }
}
