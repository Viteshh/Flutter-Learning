import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/widgets/city_b_utton/city_b_utton_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SelectCityModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel1;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel2;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel3;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel4;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel5;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel6;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel7;
  // Model for cityBUtton component.
  late CityBUttonModel cityBUttonModel8;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    cityBUttonModel1 = createModel(context, () => CityBUttonModel());
    cityBUttonModel2 = createModel(context, () => CityBUttonModel());
    cityBUttonModel3 = createModel(context, () => CityBUttonModel());
    cityBUttonModel4 = createModel(context, () => CityBUttonModel());
    cityBUttonModel5 = createModel(context, () => CityBUttonModel());
    cityBUttonModel6 = createModel(context, () => CityBUttonModel());
    cityBUttonModel7 = createModel(context, () => CityBUttonModel());
    cityBUttonModel8 = createModel(context, () => CityBUttonModel());
  }

  void dispose() {
    textController?.dispose();
    cityBUttonModel1.dispose();
    cityBUttonModel2.dispose();
    cityBUttonModel3.dispose();
    cityBUttonModel4.dispose();
    cityBUttonModel5.dispose();
    cityBUttonModel6.dispose();
    cityBUttonModel7.dispose();
    cityBUttonModel8.dispose();
  }

  /// Additional helper methods are added here.

}
