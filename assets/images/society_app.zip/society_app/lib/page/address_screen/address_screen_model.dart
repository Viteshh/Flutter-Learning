import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widgets/custom_bottom_sheet_two/custom_bottom_sheet_two_widget.dart';
import '/widgets/text_field/text_field_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddressScreenModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // Model for cityField.
  late TextFieldModel cityFieldModel;
  // Model for localAreaField.
  late TextFieldModel localAreaFieldModel;
  // Model for socField.
  late TextFieldModel socFieldModel;
  // Model for landmarkField.
  late TextFieldModel landmarkFieldModel;
  // Model for pinCodeField.
  late TextFieldModel pinCodeFieldModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    cityFieldModel = createModel(context, () => TextFieldModel());
    localAreaFieldModel = createModel(context, () => TextFieldModel());
    socFieldModel = createModel(context, () => TextFieldModel());
    landmarkFieldModel = createModel(context, () => TextFieldModel());
    pinCodeFieldModel = createModel(context, () => TextFieldModel());

    cityFieldModel.textControllerValidator = _formTextFieldValidator;
  }

  void dispose() {
    cityFieldModel.dispose();
    localAreaFieldModel.dispose();
    socFieldModel.dispose();
    landmarkFieldModel.dispose();
    pinCodeFieldModel.dispose();
  }

  /// Additional helper methods are added here.

  String? _formTextFieldValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }
}
