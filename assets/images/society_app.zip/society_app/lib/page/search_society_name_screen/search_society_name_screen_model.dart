import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/widgets/search_textfield/search_textfield_widget.dart';
import '/widgets/text_field/text_field_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SearchSocietyNameScreenModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // Model for cityField.
  late TextFieldModel cityFieldModel;
  // Model for localAreaField.
  late TextFieldModel localAreaFieldModel;
  // Model for search_textfield component.
  late SearchTextfieldModel searchTextfieldModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    cityFieldModel = createModel(context, () => TextFieldModel());
    localAreaFieldModel = createModel(context, () => TextFieldModel());
    searchTextfieldModel = createModel(context, () => SearchTextfieldModel());

    cityFieldModel.textControllerValidator = _formTextFieldValidator1;
    localAreaFieldModel.textControllerValidator = _formTextFieldValidator2;
    searchTextfieldModel.textControllerValidator = _formTextFieldValidator3;
  }

  void dispose() {
    cityFieldModel.dispose();
    localAreaFieldModel.dispose();
    searchTextfieldModel.dispose();
  }

  /// Additional helper methods are added here.

  String? _formTextFieldValidator1(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Enter City';
    }

    return null;
  }

  String? _formTextFieldValidator2(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  String? _formTextFieldValidator3(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }
}
