import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/widgets/custom_my_booking_card/custom_my_booking_card_widget.dart';
import '/widgets/rent_now_card/rent_now_card_widget.dart';
import '/widgets/scrollwidget/scrollwidget_widget.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DashboardScreenModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  // Model for rent_now_card component.
  late RentNowCardModel rentNowCardModel;
  // Model for scrollwidget component.
  late ScrollwidgetModel scrollwidgetModel1;
  // Model for scrollwidget component.
  late ScrollwidgetModel scrollwidgetModel2;
  // Model for scrollwidget component.
  late ScrollwidgetModel scrollwidgetModel3;
  // Model for custom_my_booking_card component.
  late CustomMyBookingCardModel customMyBookingCardModel;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    rentNowCardModel = createModel(context, () => RentNowCardModel());
    scrollwidgetModel1 = createModel(context, () => ScrollwidgetModel());
    scrollwidgetModel2 = createModel(context, () => ScrollwidgetModel());
    scrollwidgetModel3 = createModel(context, () => ScrollwidgetModel());
    customMyBookingCardModel =
        createModel(context, () => CustomMyBookingCardModel());
  }

  void dispose() {
    rentNowCardModel.dispose();
    scrollwidgetModel1.dispose();
    scrollwidgetModel2.dispose();
    scrollwidgetModel3.dispose();
    customMyBookingCardModel.dispose();
  }

  /// Additional helper methods are added here.

}
