import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'search_textfield_model.dart';
export 'search_textfield_model.dart';

class SearchTextfieldWidget extends StatefulWidget {
  const SearchTextfieldWidget({
    Key? key,
    this.societyName,
  }) : super(key: key);

  final String? societyName;

  @override
  _SearchTextfieldWidgetState createState() => _SearchTextfieldWidgetState();
}

class _SearchTextfieldWidgetState extends State<SearchTextfieldWidget> {
  late SearchTextfieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SearchTextfieldModel());

    _model.textController ??= TextEditingController();
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: _model.textController,
      autofocus: true,
      obscureText: false,
      decoration: InputDecoration(
        hintText: widget.societyName,
        hintStyle: FlutterFlowTheme.of(context).bodySmall.override(
              fontFamily: 'Poppins',
              color: Color(0x80000000),
            ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).accent3,
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).secondary,
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0x00000000),
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0x00000000),
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
        contentPadding: EdgeInsetsDirectional.fromSTEB(18.0, 11.0, 18.0, 11.0),
        prefixIcon: Icon(
          Icons.search,
          color: FlutterFlowTheme.of(context).secondary,
          size: 20.0,
        ),
      ),
      style: FlutterFlowTheme.of(context).bodyMedium.override(
            fontFamily: 'DM Sans',
          ),
      validator: _model.textControllerValidator.asValidator(context),
    );
  }
}
