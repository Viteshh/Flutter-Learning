import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _myFlutterAppFamily = 'MyFlutterApp';

  // MyFlutterApp
  static const IconData kmumbai =
      IconData(0xe801, fontFamily: _myFlutterAppFamily);
  static const IconData kbangluru =
      IconData(0xe802, fontFamily: _myFlutterAppFamily);
  static const IconData kchennai =
      IconData(0xe803, fontFamily: _myFlutterAppFamily);
  static const IconData khyderabad =
      IconData(0xe804, fontFamily: _myFlutterAppFamily);
  static const IconData kkolkata =
      IconData(0xe805, fontFamily: _myFlutterAppFamily);
  static const IconData kpune =
      IconData(0xe806, fontFamily: _myFlutterAppFamily);
  static const IconData klucknow =
      IconData(0xe807, fontFamily: _myFlutterAppFamily);
  static const IconData kdelhi =
      IconData(0xe808, fontFamily: _myFlutterAppFamily);
}
